The Hand Mesh was made using the Makehuman Community Edition
It was slightly modified inside Blender 3D and textured inside Substance Painter

If there should be concerns regarding License issues
https://github.com/makehumancommunity/makehuman/blob/master/LICENSE.md

under point D of the makehuman communtiy edition license
https://github.com/makehumancommunity/makehuman/blob/master/LICENSE.md#d-concerning-the-output-from-makehuman
As the assets have been released under CC0, there is no limitation on what you can do with this combined output.
The MakeHuman project makes no claim whatsoever over output such as:

    Exports to files (FBX, OBJ, DAE, MHX2...)
    Exports via direct integration (import via MPFB)
    Graphical data generated via scripting or plugins
    Renderings
    Screenshots
    Saved model files
